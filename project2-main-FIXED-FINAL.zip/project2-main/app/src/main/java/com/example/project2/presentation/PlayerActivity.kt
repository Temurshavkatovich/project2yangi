package com.example.project2.presentation

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.project2.data.Song
import com.example.project2.ui.theme.PlayerScreen
import com.example.project2.ui.theme.Project2Theme

class PlayerActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val mySongList = intent.getParcelableArrayListExtra<Song>("SONG_LIST") ?: emptyList<Song>()
        val initialIndex = intent.getIntExtra("SONG_INDEX", 0)
        setContent {
            Project2Theme {
                PlayerScreen(
                    songList = mySongList,
                    initialIndex = initialIndex,
                    onBack = { finish() }
                )
            }
        }
    }
}